<?php

namespace Database\Seeders;

use App\Models\SiteSetting;
use Illuminate\Database\Seeder;

class SiteSettingSeeder extends Seeder
{
    public function run(): void
    {
        $defaults = [
            'about_title_en' => 'Terma Medical: Your Trusted Partner in the Healthcare Journey.',
            'about_title_ar' => 'تيرما للمعدات الطبية: شريككم الموثوق في رحلة الرعاية الصحية.',
            'about_desc_en' => 'We are not just suppliers; we are strategic partners aiming to empower medical institutions to provide the best care possible.',
            'about_desc_ar' => 'نحن لسنا مجرد موردين، بل نحن شركاء استراتيجيون نهدف إلى تمكين المؤسسات الطبية لتقديم أفضل رعاية ممكنة.',
            'phone' => '+249 91 903 3303',
            'whatsapp_number' => '249919033303',
            'email_info' => 'info@termamed.com',
            'email_marketing' => 'markting@termamed.com',
            'email_sales' => 'sales@terma-medical.com',
            'social_facebook' => '#',
            'social_twitter' => '#',
            'social_linkedin' => '#',
            'social_instagram' => '#',
        ];

        foreach ($defaults as $key => $value) {
            SiteSetting::firstOrCreate(
                ['key' => $key],
                ['value' => $value]
            );
        }
    }
}
