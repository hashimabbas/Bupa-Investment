<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\User;

class EngineerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // 1. Get or create the 'engineer' and 'technician' roles
        $engineerRole = Role::firstOrCreate([
            'name' => 'engineer',
            'guard_name' => 'web'
        ]);

        $technicianRole = Role::firstOrCreate([
            'name' => 'technician',
            'guard_name' => 'web'
        ]);

        // 2. Define the specific permissions for field engineers / technicians
        $engineerPermissions = [
            // Custom/Legacy Permissions
            'view engineering dashboard',
            'manage engineering tasks',
            'manage schedules',
            'view maintenance visits',
            
            // Dotted Permissions for Medical Modules
            'customers.view',
            'equipment.view',
            'equipment.edit',
            'tickets.view',
            'tickets.edit',
            'visits.view',
            'visits.create',
            'visits.edit',
            'tasks.view',
            'tasks.create',
            'tasks.edit',
            'schedule.view',
        ];

        // 3. Ensure all these permissions exist and assign them to the roles
        $permissionsToAssign = [];
        foreach ($engineerPermissions as $permName) {
            $permission = Permission::where('name', $permName)->first();
            if ($permission) {
                $permissionsToAssign[] = $permission;
            }
        }

        $engineerRole->syncPermissions($permissionsToAssign);
        $technicianRole->syncPermissions($permissionsToAssign);

        // 4. Find all seeded users with the 'engineer' / 'technician' role column and assign them the Spatie roles
        $engineers = User::where('role', 'engineer')->get();
        foreach ($engineers as $engineer) {
            $engineer->assignRole('engineer');
        }

        $technicians = User::where('role', 'technician')->get();
        foreach ($technicians as $technician) {
            $technician->assignRole('technician');
        }
    }
}
