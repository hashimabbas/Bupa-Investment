<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Models\Customer;
use App\Models\Equipment;
use App\Models\Engineer;
use App\Models\MaintenanceTicket;
use App\Models\MaintenanceVisit;
use App\Models\User;
use App\Enums\CustomerType;
use App\Enums\EquipmentStatus;
use App\Enums\OwnershipType;
use App\Enums\TicketPriority;
use App\Enums\TicketStatus;
use App\Enums\TicketType;
use Illuminate\Support\Str;

class MedicalOperationsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $admin = User::where('role', 'admin')->first();

        // 1. Create Engineers
        $engineers = [
            [
                'name' => 'Eng. Ahmed Ali',
                'specialization' => 'MRI & Imaging Systems',
                'region' => 'Khartoum',
                'email' => 'ahmed.eng@terma.com',
                'code' => 'ENG-001',
            ],
            [
                'name' => 'Eng. Sarah Omer',
                'specialization' => 'Surgical & ICU Equipment',
                'region' => 'Omdurman',
                'email' => 'sarah.eng@terma.com',
                'code' => 'ENG-002',
            ],
            [
                'name' => 'Eng. Khalid Idris',
                'specialization' => 'Laboratory Analyzers',
                'region' => 'Bahri',
                'email' => 'khalid.eng@terma.com',
                'code' => 'ENG-003',
            ],
        ];

        foreach ($engineers as $engData) {
            $user = User::updateOrCreate(
                ['email' => $engData['email']],
                [
                    'name' => $engData['name'],
                    'role' => 'engineer',
                    'job_title' => 'Field Service Engineer',
                    'password' => \Illuminate\Support\Facades\Hash::make('password'),
                ]
            );

            Engineer::updateOrCreate(
                ['user_id' => $user->id],
                [
                    'employee_code' => $engData['code'],
                    'specialization' => $engData['specialization'],
                    'phone' => '+249912345678',
                    'region' => $engData['region'],
                    'availability_status' => 'available',
                    'certifications' => ['Siemens MRI Specialist', 'GE Healthcare Certified'],
                ]
            );
        }

        $allEngineers = Engineer::all();

        // 2. Create Customers
        $customers = [
            [
                'name' => 'Royal Care International Hospital',
                'type' => CustomerType::PRIVATE,
                'contact_person' => 'Dr. Mutasim',
                'city' => 'Khartoum',
                'lat' => 15.5881,
                'lng' => 32.5342,
            ],
            [
                'name' => 'Al-Zaitouna Specialist Hospital',
                'type' => CustomerType::PRIVATE,
                'contact_person' => 'Sr. Amina',
                'city' => 'Khartoum',
                'lat' => 15.6000,
                'lng' => 32.5300,
            ],
            [
                'name' => 'National Ribat University Hospital',
                'type' => CustomerType::GOVERNMENT,
                'contact_person' => 'General Khalid',
                'city' => 'Burri',
                'lat' => 15.6100,
                'lng' => 32.5500,
            ],
        ];

        foreach ($customers as $custData) {
            $email = Str::slug($custData['name']) . '@hospital.com';
            $customer = Customer::updateOrCreate(
                ['email' => $email],
                [
                    'name' => $custData['name'],
                    'type' => $custData['type'],
                    'contact_person' => $custData['contact_person'],
                    'phone' => '+249123456789',
                    'address' => 'Street 15, ' . $custData['city'],
                    'city' => $custData['city'],
                    'latitude' => $custData['lat'],
                    'longitude' => $custData['lng'],
                    'account_manager_id' => $admin?->id,
                ]
            );

            // 3. Create Equipment for each customer
            $equipments = [
                [
                    'product_name' => 'MRI Magnetom Sola',
                    'manufacturer' => 'Siemens',
                    'model' => 'Sola 1.5T',
                    'serial_number' => 'SN-' . Str::random(8),
                    'maintenance_schedule' => 'quarterly',
                    'ownership_type' => OwnershipType::OWNED,
                ],
                [
                    'product_name' => 'C-Arm Imaging System',
                    'manufacturer' => 'GE Healthcare',
                    'model' => 'OEC One',
                    'serial_number' => 'SN-' . Str::random(8),
                    'maintenance_schedule' => 'monthly',
                    'ownership_type' => OwnershipType::LEASED,
                ],
                [
                    'product_name' => 'Ventilator Savina 300',
                    'manufacturer' => 'Dräger',
                    'model' => 'Savina 300',
                    'serial_number' => 'SN-' . Str::random(8),
                    'maintenance_schedule' => 'yearly',
                    'ownership_type' => OwnershipType::UNDER_CONTRACT,
                ],
            ];

            foreach ($equipments as $eqData) {
                $equipment = Equipment::firstOrCreate(
                    [
                        'customer_id' => $customer->id,
                        'model' => $eqData['model'],
                    ],
                    array_merge($eqData, [
                        'installation_date' => now()->subMonths(rand(6, 24)),
                        'warranty_expiry' => now()->addMonths(rand(6, 18)),
                        'status' => EquipmentStatus::ACTIVE,
                        'location_inside_facility' => 'Main Wing, Floor ' . rand(1, 4),
                        'last_maintenance_at' => now()->subMonths(2),
                        'next_maintenance_at' => now()->addMonths(1),
                    ])
                );

                // 4. Create some tickets (Preventive & Emergency)
                if ($allEngineers->isNotEmpty()) {
                    MaintenanceTicket::firstOrCreate(
                        [
                            'customer_id' => $customer->id,
                            'equipment_id' => $equipment->id,
                            'type' => TicketType::PREVENTIVE,
                            'status' => TicketStatus::COMPLETED,
                        ],
                        [
                            'engineer_id' => $allEngineers->random()->id,
                            'priority' => TicketPriority::MEDIUM,
                            'issue_description' => 'Routine inspection and calibration.',
                            'scheduled_date' => now()->subDays(rand(10, 30)),
                            'completed_at' => now()->subDays(rand(10, 30)),
                            'sla_deadline' => now()->subDays(rand(10, 30))->addHours(24),
                            'response_time_minutes' => 120,
                        ]
                    );

                    MaintenanceTicket::firstOrCreate(
                        [
                            'customer_id' => $customer->id,
                            'equipment_id' => $equipment->id,
                            'type' => TicketType::EMERGENCY,
                            'status' => TicketStatus::IN_PROGRESS,
                        ],
                        [
                            'engineer_id' => $allEngineers->random()->id,
                            'priority' => TicketPriority::URGENT,
                            'issue_description' => 'Error code E-204: Power supply failure suspected.',
                            'scheduled_date' => now(),
                            'sla_deadline' => now()->addHours(4),
                        ]
                    );
                }
            }
        }
    }
}
