<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $modules = [
            'leads' => 'CRM Leads & Pipeline',
            'products' => 'Medical Products Catalog',
            'partners' => 'Global Partners & Manufacturers',
            'departments' => 'Medical Departments',
            'services' => 'Services & Solutions',
            'gallery' => 'Gallery Management',
            'hero_slides' => 'Homepage Hero Slider',
            'offers' => 'Offers & Promotions',
            'users' => 'Admin Users & Permissions',
            'customers' => 'Customers & Medical Sites',
            'equipment' => 'Medical Equipment Catalog',
            'engineers' => 'Engineers Directory',
            'tickets' => 'Maintenance Tickets',
            'visits' => 'Field Maintenance Visits',
            'tasks' => 'Engineering Tasks',
            'schedule' => 'Engineering Schedules',
            'testimonials' => 'Client Testimonials & Videos',
        ];

        $actions = [
            'view' => 'Can view items',
            'create' => 'Can create new items',
            'edit' => 'Can edit existing items',
            'delete' => 'Can delete items',
        ];

        foreach ($modules as $moduleKey => $moduleName) {
            foreach ($actions as $actionKey => $actionName) {
                \App\Models\Permission::updateOrCreate(
                    ['name' => "{$moduleKey}.{$actionKey}"],
                    [
                        'module' => $moduleKey,
                        'description' => "{$actionName} in {$moduleName}",
                    ]
                );
            }
        }

        // Custom/Legacy Permissions
        $customPermissions = [
            'view engineering dashboard' => 'engineering',
            'manage engineering tasks' => 'engineering',
            'manage schedules' => 'engineering',
            'view maintenance visits' => 'visits',
        ];

        foreach ($customPermissions as $permName => $moduleKey) {
            \App\Models\Permission::updateOrCreate(
                ['name' => $permName],
                [
                    'module' => $moduleKey,
                    'description' => "Custom permission: {$permName}",
                ]
            );
        }
    }

}
